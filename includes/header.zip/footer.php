<footer class="bg-gray-800 text-gray-300 text-center py-3 mt-10">
  <div class="max-w-7xl mx-auto px-4">
    <p>&copy; <?php echo date('Y'); ?> Flash Shop. Tous droits réservés.</p>
    <p>
      Contactez-nous : 
      <a href="/FlashShop/contact.php" class="text-green-400 hover:underline">
        Formulaire de contact
      </a>
    </p>
  </div>
</footer>